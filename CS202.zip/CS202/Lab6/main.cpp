#include "shape.h"

int main()
{
    tests();
    return 0;
}


