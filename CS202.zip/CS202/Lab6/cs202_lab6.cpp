#include "shape.h"

//Step 5 - Implement the Point class operators

Point Point::operator + (const Point& p) const
{
//    if(p)
 //   {
    Point temp;
    temp.x = x + p.x;
    temp.y = y + p.y;
    return temp;
}

Point& Point::operator += (const Point& p)
{
    
        x = x + p.x;
        y = y + p.y;
        return *this;
    
}

bool Point::operator == (const Point& p) const
{
    if(x == p.x  && y == p.y)
        return true;
    return false;    
}

ostream& operator << (ostream& out, const Point& p)
{
    out << "(" << p.x << ",";
    out << p.y << ")";
    return out;
}


//Step 6 - Impelment the Shape class operators

Shape& Shape::operator = (const Shape& s)
{
    if(this == &s)
        return * this;
    if(color)
        delete [] color;
    color = new char[strlen(s.color) + 1];
    strcpy(color, s.color);
    center = s.center;
    return *this;  
}

Shape& Shape::operator += (const Point& p)
{
    center += p;
    /*char * temp = new char[strlen(color+p.color+1)];
    strcpy(temp, color);
    strcat(temp, p.color);*/
    return *this;    
}

Shape operator + (const Point& p, const Shape& s)
{
    Shape temp(s); 
    temp.center += p;
    /*char * temp = new char[strlen(color+p.color+1)];
    strcpy(temp, color);
    strcat(temp, p.color);*/
    return temp;
}

Shape operator + (const Shape& s, const Point& p)
{
    Shape temp(s); 
    temp.center += p;
    return temp;
}

//Step 7 Implement the Circle class operators

Circle operator + (const Point& p, const Circle& c)
{
    
}

Circle operator + (const Circle& c, const Point& p)
{

}

Circle& Circle::operator = (const Circle& c)
{

}

ostream& operator << (ostream& out, const Shape& s)
{

}


