#include "list.h"
//Count the number of times the requested data is in a linear linked list,
//return the number of items found
int list::num_times(int match)
{
    if(!head)
        return 0;
    return num_times(head, match);

}
int list::num_times(node * head, int match)
{
    if(!head)
        return 0;
    if(head -> data == match)
        return num_times(head -> next, match) + 1;
    else
        return num_times(head -> next, match) + 0;

}

//Display the first and last item in the linear linked list;
//return the sum of the first and last data items to the main;
int list::display_first_last()
{
    if(!head)
    {
        tail = NULL;
        return 0;
    }
    return display_first_last(head);
}

int list::display_first_last(node * head)
{
    if(!head)
        return 0;
    if(!head -> next)
    {
        return head -> data + this -> head -> data;
    }
    else
        return display_first_last(head -> next);

}

bool list::remove_except()
{ 
    if(!head)
        return false;
    if(!head -> next)
        return false;
    if(!head -> next -> next)
        return false;
    return remove_except(head);
}

bool list::remove_except(node *& head)
{
    if ( head->next ->next == NULL)
        return true;
  /*node * temp = head->next;
  head->next = NULL;
  delete head;
  head = temp;
  return remove_except(head);*/
    node * temp = head;
    head = head -> next;
    temp -> next = NULL;
    delete temp;
    return remove_except(head);
}









