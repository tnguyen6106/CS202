#include "list.h"

int main()
{
    list object;
    object.build();    //builds a LLL
    object.display();  //displays the LLL

    //PLEASE PUT YOUR CODE HERE to call the function assigned
    //cout << endl << "Number of items found based on the argument is: " << object.num_times(2) << endl;
    //cout << endl << "Sum of first and last node: " << object.display_first_last() << endl;

    

    object.display();  //displays the LLL again!
   
    
    return 0;
}
