#include "clist.h"

int list::copy_special(list & new_list)
{
    if(!rear)
        return 0;
    /*else if(new_list.rear != 2)
    {
        new_list.rear = new node;
        new_list.rear -> data = rear -> data;
        new_list.rear -> next = new_list.rear;
    }*/
    return copy_special(new_list.rear, rear -> next);
}

int list::copy_special(node *& new_copy, node * original)
{
    /*if(!new_copy && this -> rear -> data != 2)
    {
        new_copy = new node;
        new_copy -> data = this -> rear -> data;
        new_copy -> next = new_copy;
        return copy_special(new_copy -> next, original -> next -> next) + 1;
    }
    else if(!new_copy && this -> rear -> data == 2)
    {
        return copy_special(new_copy -> next, original -> next -> next) + 0;
    }*/
    if(original == this -> rear)
    { 
        if(original -> data != 2)
        {
            //new_copy -> next = new node;
            node * temp = new node;
            temp -> data = original -> data;
            temp -> next = new_copy -> next;
            new_copy -> next = temp;
            /*new_copy -> next -> data = original -> data;
            new_copy -> next = this -> new_copy;*/
            return 1;
        }
        else
            return 0;
    } 
    if(!new_copy && original -> data != 2)
    {
        new_copy = new node;
        new_copy -> data = original -> data;
        new_copy -> next = new_copy;
    }
    

        /*node * new_node = new node;
        new_node -> data = original ->data;
        new_copy ->next = new_node;
        new_node-> next = this->new_copy;*/
        node * temp = new node;
        temp -> data = original -> data;
        temp -> next = new_copy -> next;
        new_copy -> next = temp;
        /* new_copy = new_copy -> next;
        new_copy -> next = new node;
        new_copy -> next -> data = original -> data;
        new_copy -> next = this -> new_copy;*/
        return copy_special(new_copy -> next, original -> next) + 1;
    }

    return copy_special(new_copy, original -> next) + 0;
    
    //return copy_special(new_copy, original -> next) + 0;
    
    

}
