#include "table.h"

//Display all data greater than root's inorder successor.
//Return the number of nodes displayed

int table::find_inorder(node * root)
{
    if(!root)
        return 0;
    if(!root -> left)//root -> left == NULL)
    {
        cout << "Inorder successor's data is: " << root -> data << endl; 
        return root -> data;
    }
    return find_inorder(root -> left); 
}
   
int table::display_greater_inorder()
{
    if(!root)
        return 0;
    int inorder_data = find_inorder(root -> right);
    int count = 0;
    display_greater_inorder(root, inorder_data, count);
    return count;
}

int table::display_greater_inorder(node * root, int value, int & count_value)
{
    if(root == NULL)
        return 0;
    display_greater_inorder(root -> left, value, count_value);
    if(root -> data > value)
    {
        cout << root -> data << " ";
        count_value += 1;
    }
    display_greater_inorder(root -> right, value, count_value);
    return 1;
}

//Copy the longest path into another three.
//Return the number of copied nodes that have data divisible by 3.
int table::copy_longest(table & to_copy)
{
    return copy_longest(root, to_copy.root);
}

int table::find_height(node * root)
{
    if(root == NULL)
        return 0;
    int left = find_height(root -> left);
    int right = find_height(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}

int table::copy_longest(node * source, node *& dest)
{
    if(source == NULL)
        return 0;
    int count = 0;
    dest = new node;
    dest -> data = source -> data;
    dest -> left = NULL;
    dest -> right = NULL;
    if(dest -> data % 3 == 0)
    {
        count += 1;
    }
    int left = find_height(source -> left);
    int right = find_height(source -> right);
    if(left > right)
        return copy_longest(source -> left, dest -> left) + count;
    else
        return copy_longest(source -> right, dest -> right) + count;
}

//Question 3
//Calculate average of the data at a level that is asked by user input
//Return that average number to main
float table::average_level(int level)
{
    if(!root)
        return 0;
    int sum = 0;
    int total_nodes = 0;
    average_level(root, level, sum, total_nodes);
    return (float)sum/(float)total_nodes;
}

int table::average_level(node * root, int level, int & sum, int & nodes)
{
    if(!root)
        return 0;
    if(level == 1)
    {
        sum += root -> data;
        nodes += 1;
    }
    --level;
    /*int start = 1;
    if(start <= level)
    {
        sum += root -> data;
        ++start;
    }*/
    return average_level(root -> left, level, sum, nodes) + average_level(root -> right, level, sum, nodes);
}



//Question 4
//Calculate the height of the inorder successor
int table::inorder_height()
{
    if(!root)
        return 0;
    if(!root -> right)
        return 0;
    return inorder_height(root -> right);
}

int table::inorder_height(node * root)
{
    if(!root -> left)
        return 0;
    return inorder_height(root -> left) + 1;
}


//Question 5
//Copy a tree into two trees (even & odd values)
//Return average of original tree
float table::copy_two_tree(table & odd, table & even)
{
    if(!root)
        return 0;
    int sum_data = 0;
    int total_nodes = copy_two_tree(root, odd.root, even.root, sum_data);
    return sum_data/total_nodes;
}

void table::insert_node(node * source, node *& dest)
{
    if(!dest)
    {
        dest = new node;
        dest -> data = source -> data;
        dest -> left = NULL;
        dest -> right = NULL;
        return;
    }
    else 
    {
        if(dest -> data >= source -> data)
            return insert_node(source, dest -> right);
        else
            return insert_node(source, dest -> left);   
    }
}

int table::copy_two_tree(node * source, node *& odd, node *& even, int & sum)
{
    if(!source)
        return 0;
    if(source -> data % 2 == 0)
    {
        insert_node(source, even);
    }
    else
    {
        insert_node(source, odd);
    }
    sum += source -> data;
    return copy_two_tree(source -> left, odd, even, sum) + copy_two_tree(source -> right, odd, even, sum) + 1;
}

//Question 6
//Return the number of nodes that divide roots inorder successor
//evenly
int table::count_inorder_divisiable()
{
    if(!root)
        return 0;
    if(!root -> right)
        return 0;
    int inorder_data = find_inorder_data(root -> right);
    return divide_successor(root, inorder_data);
}

int table::divide_successor(node * root, int data)
{
    int count = 0; 
    if(!root)
        return 0;
    if(data % root -> data == 0)
        ++count;
    return divide_successor(root -> left, data) + divide_successor(root -> right, data) + count;
}

int table::find_inorder_data(node * root)
{
    if(!root -> left)
        return root -> data;
    return find_inorder_data(root -> left);
}
//For fun
//Rotate an ARR by 90 degrees to the right


//Copy into a new BST except for smallest data
//Return the number of nodes copied
int table::copy_except(table & destination)
{
    return copy_except(root, destination.root);    
}

int table::copy_except(node * source, node *& dest)
{
    if(!source)
        return 0;
    int data = smallest ( this->root);
    if ( source ->data != data)
        insert_node(source, dest);
    return copy_except(source -> left, dest) + copy_except(source -> right, dest) + 1;
}
int table :: smallest ( node * src)
{
        if ( !src->left)
            return src->data;
        return smallest ( src->left); 
}

//=======================================================================================//
//CS299 Questions

//Count number of times root's data appears in the list. Return the count
int table::count_root()
{
    if(!root)
        return 0;
    return count_root(root);
}

int table::count_root(node * root)
{
    if(!root)
        return 0;
    if(root -> data == this -> root -> data)
        return count_root(root -> left) + count_root(root -> right) + 1;
    return count_root(root -> left) + count_root(root -> right) + 0;
}

//Remove the root's inorder sucessor. Return the data of the inorder sucessor
int table::remove_inorder()
{
    if(!root || !root -> right)
        return 0;
    return remove_inorder(root -> right);
}

int table::delete_inorder(node *& root)
{
    int inorder_data = 0; 
    if(!root -> right)
    {
        inorder_data = root -> data;
        delete root;
        root = NULL;
        return inorder_data;
    }
    else
    {
        inorder_data = root -> data;
        node * temp = root;
        root = root -> right;
        temp -> right = NULL;
        delete temp;
        return inorder_data;
    }
}
int table::remove_inorder(node *& root)
{
    if(!root)
        return 0;
    if(!root -> left)
    {
        return delete_inorder(root);
    }
    return remove_inorder(root -> left);
}

//Display the sum of the shortest path
int table::sum_shortest()
{
    if(!root)
        return 0;
    int sum = 0;
    sum_shortest(root, sum);
    return sum;
}

int table::find_height_2(node * root)
{
    if(!root)
        return 0;
    int left = find_height_2(root -> left);
    int right = find_height_2(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}

int table::sum_shortest(node * root, int & sum)
{
    if(!root)
        return 0;
    sum += root -> data;
    cout << root -> data << " ";
    if(root -> left && root -> right)
    {
        int left = find_height_2(root -> left);
        int right = find_height_2(root -> right);
        if(left > right)
        {
            sum_shortest(root -> right, sum);
        }
        else
        {
            sum_shortest(root -> left, sum);
        }
    }
    else if( root -> left && !root->right)
    {
         sum_shortest(root -> left, sum);
    }
    else if(!root -> left && root -> right)
    {
         sum_shortest(root -> right, sum);
    }
    else if ( !root -> left && ! root -> right)
        return 0;
    return 0;
}

//Display sum of the longest
int table::sum_longest()
{
    if(!root)
        return 0;
    int sum = 0;
    return sum_longest(root, sum) + sum;
}


int table::sum_longest(node * root, int & sum)
{
    if(!root)
        return 0;
    sum += root -> data;
    cout << root -> data << " ";
    int left = find_height_2(root -> left);
    int right = find_height_2(root -> right);
    if(left > right)
    {
        sum_longest(root -> left, sum);
    }
    else
        sum_longest(root -> right, sum);
    return 0;
}

//Display the average of every path to main
int table::find_path_average()
{
    if(!root)
        return 0;
    int sum = 0;
    int total_nodes = 0;
    return find_path_average(root, sum, total_nodes);
}

float table::find_path_average(node * root, int sum, int nodes)
{
    sum += root -> data; 
    nodes += 1;
    if(!root)
        return 0;

    if(!root -> left && !root -> right)
    {
        float average = (float)sum/(float)nodes;
        cout << average << " ";
        return 0;
    }
    else if(!root -> left && root -> right)
    {
        return find_path_average(root -> right, sum, nodes);
    }
    else if(root -> left && !root -> right)
        return find_path_average(root -> left, sum, nodes);
    else if(root -> left && root -> right)
    {
        find_path_average(root -> right, sum, nodes);
        find_path_average(root -> left, sum, nodes);
    }
    return 0;
}

//Find the average of odd level and return the sum of the average
//*return the number of nodes of the tree* <- intital thought, changed mind at last
int table::odd_level_average()
{
    if(!root)
        return 0;
    int level = find_height_2(root);
    //int sum_data = 0;
    //int total_nodes = 0
    return odd_level_average(level);
}

int table::find_height_3(node * root)
{
    if(!root)
        return 0;
    int left = find_height_3(root -> left);
    int right = find_height_3(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}
int table::odd_level_average_helper(node * root, int & sum, int & nodes, int level)
{
    if(!root)
        return 0;
    if(level == 1)
    {
        sum += root -> data;
        nodes += 1;
        return 0;
    }
    --level;
    return odd_level_average_helper(root -> left, sum, nodes, level) + odd_level_average_helper(root -> right, sum, nodes, level);
}

int table::odd_level_average(int level)
{
    float average = 0; 
    if(level == 1)
    {   
        cout << "Level: " << level;
        cout << "\nAverage: " << root -> data;
        average += root -> data;
        return average;
    }
    if(level % 2 != 0)
    {
        int sum = 0;
        int total_nodes = 0;
        odd_level_average_helper(root, sum, total_nodes, level); 
        average = (float)sum/(float)total_nodes;
        cout << "Level: " << level << endl;
        cout << "Average:" << average << endl;
    }
    return odd_level_average(level -1) + average;
}


//Find the average of all the odd levels and calculate the average of the averages
//Return the average of the averages to main
float table::avg_odd_avg()
{
    if(!root)
        return 0;
    float sum_avg = 0.0;
    int level = find_height_3(root);
    int odd_nodes = avg_odd_avg(sum_avg, level);
    return sum_avg/(float)odd_nodes;
}

int table::avg_odd_avg_helper(node * root, int & sum, int & nodes, int level)
{
    if(!root)
        return 0;
    if(level == 1)
    {
        sum += root -> data;
        nodes += 1;
        return 0;
    }
    --level;
    return avg_odd_avg_helper(root -> left, sum, nodes, level) + avg_odd_avg_helper(root -> right, sum, nodes, level);
}

int table::avg_odd_avg(float & sum_avg, int level)
{
    if(level == 1)
    {
        cout << "\nLevel: " << level;
        cout << "\nAverage: " << root -> data;
        sum_avg += root -> data;
        return 1;
    }
    if(level % 2 != 0)
    {
        int sum = 0;
        int total_nodes = 0;
        avg_odd_avg_helper(root, sum, total_nodes, level);
        float average = (float)sum/(float)total_nodes;
        cout << "\nLevel: " << level;
        cout << "\nAverage: " << average;
        sum_avg += average;
        
        return avg_odd_avg(sum_avg, level -1) + 1;
    }
    return avg_odd_avg(sum_avg, level - 1) + 0;
}

//Calculate the average of unique data
float table::unique_average()
{
    if(!root)
        return 0.0;
    int sum_unique = 0;
    int total_nodes = 0;
    unique_average(root, sum_unique, total_nodes);
    return (float)sum_unique/(float)total_nodes;
}

int table::unique_average(node * root, int & sum, int & nodes)
{
    if(!root)
        return 0;
    if(check_unique(root -> data) == 0)
    {
        sum += root -> data;
        nodes += 1;
    }
    return unique_average(root -> left, sum, nodes) + unique_average(root -> right, sum, nodes);
}
int table::check_unique(int value)
{
    if(!root)
        return 0;
    int count = 0;
    return check_unique(root, value, count);
    //if(count < 2)
    //    return 0;
    //return count;
}

int table::check_unique(node * root, int value, int & count)
{
    if(!root)
        return 0; //If root reach bottom and still not yet found a math, return true
    if(value == root -> data)
        count += 1;
    if(count == 2)
        return count; //Return 1 if value is not unique in the tree
    return check_unique(root -> left, value, count) + check_unique(root -> right, value, count);
}

//Find the most frequent number(data) in the tree and return that number to main
int table::find_frequent()
{
    if(!root)
        return 0;
    int most_frequent_data = 0;
    int frequency = 0;
    find_frequent(root, most_frequent_data, frequency);
    cout << "Frequency is: " << frequency << endl;
    return most_frequent_data;
}

int table::find_frequent(node * root, int & most_frequent, int & frequency)
{
    if(!root)
        return 0;
    int data_frequency = compare_value(this -> root, root -> data);
    if(data_frequency > frequency)
    {
        frequency = data_frequency;
        most_frequent = root -> data;
    }
    return find_frequent(root -> left, most_frequent, frequency) + find_frequent(root -> right, most_frequent, frequency);
}


int table::compare_value(int value)
{
    if(!root)
        return 0;
    return compare_value(root, value);
}

int table::compare_value(node * root, int value)
{
    int count = 0;
    if(!root)
        return 0;
    if(root -> data == value)
        count += 1;
    return compare_value(root -> left, value) + compare_value(root -> right, value) + count;
}

//Display only the data that have duplicate in the BST. Return the number of nodes displayed
int table::display_duplicate()
{
    if(!root)
        return 0;
    return display_duplicate(root);
}

int table::display_duplicate(node * root)
{
    if(!root)
        return 0;
    int duplicate_count = find_duplicate(this -> root, root -> data);
    int dup_left = display_duplicate(root -> left); 
    if(duplicate_count >= 2)
    {
        //display_duplicate(root -> left);
        cout << root -> data << " ";
        return display_duplicate(root -> right) + 1 + dup_left;
    }
    return display_duplicate(root -> right) + dup_left;
}

int table::find_duplicate(node * root, int to_find)
{
    int count = 0;
    if(!root)
        return 0;
    if(root -> data == to_find)
        count += 1;
    return find_duplicate(root -> left, to_find) + find_duplicate(root -> right, to_find) + count;
}


//Display the shortest path to a leaf
//INCOMPLETE!! - Difficulty Lvl: 9000+
int table::display_shortest()
{
    if(!root)
        return 0;
    return display_shortest(root);
}

int table::find_height_4(node * root)
{
    if(!root)
        return 0;
    int left = find_height(root -> left);
    int right = find_height(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}

int table::display_shortest(node * root)
{
    if(!root)
        return 0;
    int left = find_height(root -> left);
    int right = find_height(root -> right);
    if(left > right)
    {
        cout << root -> data << " ";
        return display_shortest(root -> right);
    }
    else if(left < right)
    {
        cout << root -> data << " ";
        return display_shortest(root -> left);
    }
    return 0;
}

//Remove the longest path to a leaf
int table::remove_longest() //Wrapper function
{
    if(!root)
        return 0;
    return remove_longest(root); //Call the recursive function
}

int table::find_and_remove_inorder(node *& root) //Traverse all the way to the left
                                                 //to find inorder sucessor
{
    if(!root -> left)
        return remove_inorder_2(root);
    return find_and_remove_inorder(root -> left);
}

int table::remove_inorder_2(node *& root) //Remove inorder successor function
{
    int inorder_data = 0; 
    if(!root -> right)
    {
        inorder_data = root -> data;
        delete root;
        root = NULL;
    }
    else
    {
        inorder_data = root -> data;
        node * temp = root;
        root = root -> right;
        temp -> right = NULL;
        delete temp;
    }
    return inorder_data;
}

int table::remove_longest(node *& root) //The recursive function
{
    if(!root)
        return 0;
    int count = 0; //Count the number of nodes deleted
    //Compare height of left and right subtrees by calling the find_height_4 function
    int left = find_height_4(root -> left);
    int right = find_height_4(root -> right);
    if(left > right)
        count = remove_longest(root -> left);
    else
        count = remove_longest(root -> right);

    //After traverse all the way down to the longest path,
    //rewinding the stack and start the deletion process

    //Case 1: if there is no children, delete the current node
    if(!root -> left && !root -> right)
    {
        count += 1; 
        cout << root -> data << " "; 
        delete root;
        root = NULL;
    }
    //Case 2: if there is one child on the right
    //Connect root to the right child and delete current node
    else if(!root -> left && root -> right)
    {
        count += 1; 
        cout << root -> data << " "; node * temp = root;
        root = root -> right;
        temp -> right = NULL;
        delete temp;
    }
    //Case 3: if there is one child on the left
    //Connect root to the left child and delete current node
    else if(root -> left && !root -> right)
    {
        count += 1; 
        cout << root -> data << " "; 
        node * temp = root;
        root = root -> left;
        temp -> left = NULL;
        delete temp;
    }
    //Case 4: if there are 2 children
    //Find the data of inorder successor and delete the node of
    //inorder successor. Replace the root's data with inorder
    //successor's data afterward
    else if(root -> left && root -> right)
    {
        count += 1; 
        cout << root -> data << " "; 
        //Call the find_and_remove_inorder function to get the data
        //of inorder sucessor and delete inorder successor's node
        //at the same time
        int inorder_data = find_and_remove_inorder(root -> right);
        root -> data = inorder_data;
    }
    return count;
}

//Find the average of all the level and calculate the average of the
//average of all the level. Return that average to main
float table::avg_all_avg()
{
    if(!root)
        return 0;
    int level = find_height_3(root);
    float avg_all_avg = 0.0;
    avg_each_lvl(avg_all_avg, level);
    return avg_all_avg/(float)level;
}

int table::avg_each_lvl(node * root, int & sum, int & nodes, int lvl)
{
    if(!root)
        return 0;
    if(lvl == 1)
    {
        sum += root -> data;
        nodes += 1;
        return 0;
    }
    return avg_each_lvl(root -> left, sum, nodes, lvl-1) + avg_each_lvl(root -> right, sum, nodes, lvl -1);
}

int table::avg_each_lvl(float & avg_all_avg, int lvl)
{
    //int total_avg = 0; 
    if(lvl == 1)
    {
        cout << "Level: " << lvl << endl;
        cout << "Average: " << root -> data << endl;
        avg_all_avg += root -> data; 
        return 0;
    }
    else
    {
        int sum = 0;
        int total_nodes = 0;
        avg_each_lvl(root, sum, total_nodes, lvl);
        float avg = (float)sum/(float)total_nodes;
        cout << "Level: " << lvl << endl;
        cout << "Average: " << avg << endl;
        avg_all_avg += avg;
    }
    return avg_each_lvl(avg_all_avg, lvl -1);

}

//Counter number of nodes in a BST, excluding root
//and any node that mathces root's data. Return the count
int table::count_exclude_root()
{
    if(!root)
        return 0;
    return count_exclude_root(root, root -> data);
}

int table::count_exclude_root(node * root, int value)
{
    if(!root)
        return 0;
    if(root -> data == value)
    {
        return count_exclude_root(root -> left, value) + count_exclude_root(root -> right, value) + 0;
    }
    return count_exclude_root(root -> left, value) + count_exclude_root(root -> right, value) + 1;
}

//Find the average of all the levels and calculate the average of
//averages of all the levels - 2nd try!!
float table::count_level_avg()
{
    if(!root)
        return 0;
    int height = find_height_5(root);
    float sum_avg = 0.0;
    each_lvl_avg(height, sum_avg);
    return sum_avg/(float)height;
    
}

int table::find_height_5(node * root)
{
    if(!root)
        return 0;
    int left = find_height_5(root -> left);
    int right = find_height_5(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}

void table::avg_of_level(node * root, int level, int & total_nodes, int & sum)
{
    if(!root)
        return;
    if(level == 1)
    {
        sum += root -> data;
        total_nodes += 1;
        return;
    }
    avg_of_level(root -> left, level -1, total_nodes, sum);
    avg_of_level(root -> right, level -1, total_nodes, sum);
    return;
}

void table::each_lvl_avg(int level, float & sum_avg)
{
    if(level == 1)
    {
        cout << "Level: " << level << endl;
        cout << "Average: " << root -> data;
        sum_avg += root -> data;
        return;
    }
    else
    {
        int total_nodes = 0;
        int sum = 0;
        avg_of_level(root, level, total_nodes, sum);
        float avg = (float)sum/(float)total_nodes;
        cout << "Level: " << level << endl;
        cout << "Average: " << avg << endl;
        sum_avg += avg;
    }
    return each_lvl_avg(level -1, sum_avg); 
}





















