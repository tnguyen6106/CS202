//list.h
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

struct node
{
    int data;   //some questions use char * data;
    node * left;
    node * right;
};

class table
{
    public:
    	//These functions are supplied already
    	table();			//supplied
    	~table();			//supplied
        void build(); 		//supplied
        void display(); 	//supplied


/* ************** PLACE YOUR PUBLIC PROTOTYPE HERE ***************** */
        int display_greater_inorder();  //Display all data greater than root's inorder successor
                                        //Return the number of nodes displayed

        //Copy the longest path into another tree. Return the # of copied nodes
        //that have data divisible by 3
        int copy_longest(table & to_copy); 

        //Calculate the height of the inorder successor and return it to main
        int inorder_height();

        //Copy a tree into two trees (even & odd values)
        //Return average of original tree
        float copy_two_tree(table & odd, table & even);

        
        //Return the number of nodes that divide roots inorder successor evenly
        int count_inorder_divisiable();

        //Copy into a new BST except for smallest data
        //Return the number of nodes copied
        int copy_except(table & destination);

        //Calculate average of data at a level that is asked by user input
        //Return that average number to main
        float average_level(int level);


        //Count number of times root's data appears in the list. Return the count
        int count_root();
     
        //Remove the root's inorder sucessor. Return the data of the inorder sucessor
        int remove_inorder();
 
        //Display the sum of the shortest path
        int sum_shortest();

        //Display sum of the longest
        int sum_longest();

        //Display the average of every path to a leaf to main
        int find_path_average();

        //Find the average of odd level and return the sum of the average
        int odd_level_average();

        float avg_odd_avg();//Find the average of all the odd levels and calculate the average
                            //of the averages. Return the average of the averages to main. 
       
        //Calculate the average of unique data in the BST
        float unique_average();

        //Find the most frequent number(data) in the tree
        int find_frequent();

        //Display only the data that have duplicate in the BST.
        //Return the number of nodes displayed
        int display_duplicate();

        //Display the shortest path to a leaf
        //INCOMPLETE - Difficulty lvl: 9000+
        int display_shortest();

        //Remove the longest path to a leaf 
        int remove_longest();

        //Find the average of all the level and calculate the average of the
        //averages. Return that average to main
        float avg_all_avg();

        //Counter number of nodes in a BST, excluding root
        //and any node that mathces root's data; return the count
        int count_exclude_root();

        //Find the average of all the levels and calculate the average of
        //averages of all the levels - 2nd try!!
        float count_level_avg();

 	private:
 		node * root;

/* ************** PLACE YOUR PRIVATE PROTOTYPE HERE ***************** */
        int find_inorder(node * root); 
        int display_greater_inorder(node * root, int value, int & count_value); 

        int copy_longest(node * source, node *& dest);
        int find_height(node * root);
        int inorder_height(node * root);

        void insert_node(node * source, node *& dest);
        int copy_two_tree(node * source, node *& odd, node *& even, int & sum);
        int divide_successor(node * root, int data);
        int find_inorder_data(node * root);

        int copy_except(node * source, node *& dest);
        int smallest ( node * src);

        int average_level(node * root, int level, int & sum, int & nodes);

        int count_root(node * root);
        int delete_inorder(node *& root);
        int remove_inorder(node *& root);
        int find_height_2(node * root);
        int sum_shortest(node * root, int & sum);
        int sum_longest(node * root, int & sum);

        float find_path_average(node * root, int sum, int nodes);

        int odd_level_average_helper(node * root, int & sum, int & nodes, int level);
        int find_height_3(node * root);
        int odd_level_average(int level);


        int avg_odd_avg_helper(node * root, int & sum, int & nodes, int level);
        int avg_odd_avg(float & sum_avg, int level);

        int unique_average(node * root, int & sum, int & nodes);

        int check_unique(int value);

        int check_unique(node * root, int value, int & count);

        int find_frequent(node * root, int & most_frequent, int & frequency);

        int compare_value(int value);

        int compare_value(node * root, int value);
    
        int display_duplicate(node * root);

        int find_duplicate(node * root, int to_find);

        int display_shortest(node * root);

        int find_height_4(node * root);

        int find_and_remove_inorder(node *& root);

        int remove_inorder_2(node *& root);

        int remove_longest(node *& root);

        int avg_each_lvl(node * root, int & sum, int & nodes, int lvl);

        int avg_each_lvl(float & avg_all_avg, int lvl);

        int count_exclude_root(node * root, int value);

        int find_height_5(node * root);

        void avg_of_level(node * root, int level, int & total_nodes, int & sum);

        void each_lvl_avg(int level, float & sum_avg);
};
  

