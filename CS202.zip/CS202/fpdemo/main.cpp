#include "table.h"

int main()
{
    table object;
    table even;
    table odd;
    table object2;
    object.build(); 	//builds a BST
    object.display();	//displays a BST
    //int level = 3;
    /*  PLACE YOUR FUNCTION CALL HERE */
    //object.display_greater_inorder();
    //cout << endl;
    //object.copy_longest(object2);
    //object2.display();
    //cout << "Height from root to inorder successor is: " << object.inorder_height();
    //cout << "Average of the data in the original tree is: " << object.copy_two_tree(odd, even) << endl;
    //cout << "Number of nodes that divide the inorder successor data evenly is: " << object.count_inorder_divisiable() << endl;
    //cout << "Number of copied nodes: " << object.copy_except(object2) << endl;
    //cout << "Average of data at level " << level << " is: " << object.average_level(level) << endl;
    //cout << "Times data of root appeared: " << object.count_root() << endl;
    //cout << "Inorder data is: " << object.remove_inorder() << endl;
    //cout << "\nSum of the shortest path is: " << object.sum_shortest() << endl;
    //cout << "Sum of the longest path is: " << object.sum_longest() << endl; 
    // cout << "Display the average of every path in the tree" << endl;
    //object.find_path_average();
    //cout << "\n\nA number: " << object.odd_level_average();
    //cout << "\nAverage of average of the odd levels: " << object.avg_odd_avg();
    //cout << "Average of unique data: " << object.unique_average() << endl;
    //cout << "Most frequently appear data in BST: " << object.find_frequent() << endl;
    //cout << "\nNumber of duplicate nodes displayed: " << object.display_duplicate() << endl;
    //object.display_shortest();
    //cout << "\nNumber of nodes got deleted in the longest path: " << object.remove_longest() << endl;
    //cout << "\nAverage of all the averages of all the level: " << object.avg_all_avg() << endl;
    //cout << "\nCount of all nodes that don't have root's data: " << object.count_exclude_root() << endl;
    cout << "\nAverage of all the averages of all the level: " << object.count_level_avg() << endl;
    //odd.display();	//displays again after!
    //even.display(); 

    object.display();
    return 0;
}
