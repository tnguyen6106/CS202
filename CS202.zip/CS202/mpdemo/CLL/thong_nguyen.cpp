#include "clist.h"

int list::remove_below_avg()
{
    if(!rear)
        return 0;
    int sum = 0;
    int total_nodes = sum_total(rear -> next, sum);
    int average = sum/total_nodes;
    cout << endl << "Here is the average: " << average << endl;
    return remove_below_avg(rear -> next, average);
}

int list::sum_total(node * rear, int & total)
{
    if(rear == this -> rear)
    {
        total += rear -> data;
        return 1;
    }
    total += rear -> data;
    return sum_total(rear -> next, total) + 1;
}

int list::remove_below_avg(node *& rear, int value)
{
    if(rear -> next == this -> rear)
    {
        if(rear ->next-> data < value)
        {
            //rear = NULL;
            node * temp = this->rear;
            rear->next = temp->next;
            temp->next = NULL;
            delete temp;
            temp = NULL;
            this->rear = rear;
            return 1;
        }
        return 0;
    }
    else
    {
        if(rear -> next -> data < value)
        {
            node * temp = rear->next;
            rear->next = temp->next;
            temp->next = NULL;
            delete temp;
            return remove_below_avg(rear, value) + 1;
        }
        else
            return remove_below_avg(rear -> next, value) + 0;
    }
}

