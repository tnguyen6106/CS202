#include "store.h"
using namespace std;

//Implement each of these using exception handeling
//For each function consider if you should have the try block
//in the function or if you should have the try block in the
//calling routine. If you throw an exception without a
//try block, then add an exception specification list


//Step 5a - throw an exception if there is an invalid response
bool again()
{
    char answer;
    cout << "Again? ";
    cin >> answer;
    cin.ignore(100, '\n');
    if(answer == 'Y')
        return true;
    else if(answer == 'N')
        return false;
    else
    {
        try
        {
            if(answer != 'Y')
            {
                throw answer;
            }
            //else if(strcmp(answer, "N") == 0)
             //   return false;  

        }
        catch(char an_answer)
        {
            cout << "Invalid input.";
            return again();
        }
    }
}

//Step 5b - implement the address constructor and throw an
//exception if ther eis a null string being copied:

address::address(char * new_street, char * new_zip)
{
    /*street = new char[strlen[new_street] + 1];
    zip = new char[strlen[new_zip] + 1];
    
    strcpy(street, new_street);
    strcpy(zip, new_zip);*/
    //try
    //{
        if(!new_street || new_zip)
        {
            NULL_STRING err;
            throw err;
        }
    //}
    //catch(NULL_STRING a_struct)
    //{
              
    //}
    
}

//Step 5c - implement the set pay function and throw an
//exception if a zzero or negative pay is requested

void hourly_employee::set_pay_rate(float rate)
{
    if(rate == 0 || rate < 0)
    {
        INVALID_PAY err;
        throw err;
    }
}

// *************************** Now move to main.cpp and work there


//Step 7 - implement the two compare functions. The first
//compares the employees name. Throw an exception if there is no match
bool employee::compare(const name & match)
{
    if(find_by_name(match))
        return true;
    else
    {
        //try
        //{
            //if(strcmp(a_name, match.a_name) !=0 )//find_by_name(match) != 0)
                throw match_not_found();
        //}
    }
        /*catch(char * name)
        {
            cout << "Name not match.";
            */
                
}

//Now travere the binary search tree of reviews and
//throw an exception if there is no match
bool employee::compare(char * match)
{
   if(root -> compare(match) == 0)
       return true;
   else
   {
       try
       {
           if(root -> compare(match) != 0)
               throw(match_not_found());
       }
   }
   catch(match_not_found & err)
   {
        cout << "Match not found";
   }
}

