
struct NULL_STRING
{
    char * bad_street;
    char * bad_zip;


};

struct INVALID_PAY
{   
    float invalid_pay;

};

struct match_not_found
{
       
};
